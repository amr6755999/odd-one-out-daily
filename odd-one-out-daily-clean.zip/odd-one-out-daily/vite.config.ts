import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

// Relative asset paths let the same build work at the root or a GitHub Pages
// project path (username.github.io/repository-name/).
export default defineConfig({
  base: './',
  plugins: [react()],
  test: {
    environment: 'jsdom',
    globals: true,
    include: ['tests/**/*.test.ts'],
  },
});
